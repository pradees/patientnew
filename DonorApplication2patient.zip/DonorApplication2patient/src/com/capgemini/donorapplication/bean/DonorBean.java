package com.capgemini.donorapplication.bean;

import java.util.Date;


public class DonorBean 
{
	private int pid;
	private String pname;
	private int age;
	private String pno;
	private String pdesc;
	private Date pdate;
	
	
	
	public void setPid(int pid) {
		this.pid = pid;
	}



	public void setPname(String pname) {
		this.pname = pname;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public void setPno(String pno) {
		this.pno = pno;
	}



	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}



	public void setPdate(Date pdate) {
		this.pdate = pdate;
	}



	public int getPid() {
		return pid;
	}



	public String getPname() {
		return pname;
	}



	public int getAge() {
		return age;
	}



	public String getPno() {
		return pno;
	}



	public String getPdesc() {
		return pdesc;
	}



	public Date getPdate() {
		return pdate;
	}



	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing patient details Details \n");
		sb.append("patient Name: " +pname +"\n");
		sb.append("patient desceription : "+ pdesc +"\n");
		sb.append("Phone Number: "+ pno +"\n");
		sb.append("patient age is : "+ age +"\n");
		sb.append("Donation Date: "+ pdate);
		return sb.toString();
	}
	

	
}
