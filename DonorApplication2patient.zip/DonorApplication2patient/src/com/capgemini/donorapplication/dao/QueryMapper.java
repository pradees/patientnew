package com.capgemini.donorapplication.dao;

public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT pname,age,pno,pdesc,pdate FROM patient1";
	public static final String VIEW_DONAR_DETAILS_QUERY="SELECT pname,age,pno,pdesc,pdate FROM patient1 WHERE  pid=?";
	public static final String INSERT_QUERY="INSERT INTO patient1 VALUES(pid_sequence.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String DONARID_QUERY_SEQUENCE="SELECT pid_sequence.CURRVAL FROM DUAL";
	
	
}
